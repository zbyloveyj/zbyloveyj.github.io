(function GrowthApp(){
  "use strict";
  const DATA=window.RESET100;
  const $=id=>document.getElementById(id);
  if(!DATA || !Array.isArray(DATA.days) || DATA.days.length!==100){
    const el=$("day-content");if(el)el.textContent="课程数据未加载，请刷新页面。";
    return;
  }
  const STORE="yixw_growth_100_v1";
  const SUPPORT=window.RESET100_SUPPORT;
  if(!SUPPORT||SUPPORT.version!==2){const el=document.getElementById("day-content");if(el)el.textContent="辅助课程数据未加载，请检查网络或刷新页面。";return;}
  const TASK_IDS=["core1","core2","core3","support1","support2"];
  const LEGACY_IDS=["sleep","food","movement","reading","focus","mindfulness","mission"];
  const names=DATA.categories;
  const modes={
    lite:{name:"轻量",hint:"完成核心第1步，即可记录当天。辅助练习完全自选。",time:"建议5—15分钟"},
    regular:{name:"标准",hint:"完成当天核心3个步骤，再确认完成。两项辅助练习按时间选择。",time:"建议20—35分钟"},
    deep:{name:"深入",hint:"核心3步 + 至少1项辅助练习 + 8字以上思考记录。",time:"建议35—60分钟"}
  };
  const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const pad=n=>String(n).padStart(2,"0");
  const todayString=()=>{
    const dt=new Date();
    return [dt.getFullYear(),pad(dt.getMonth()+1),pad(dt.getDate())].join("-");
  };
  const validDate=s=>typeof s==="string"&&/^\d{4}-\d{2}-\d{2}$/.test(s)&&!Number.isNaN(new Date(s+"T12:00:00").getTime());
  const fresh=()=>({version:1,startDate:todayString(),mode:"regular",theme:"light",days:{},weeklyNotes:{}});
  let state=fresh();
  try{
    const loaded=JSON.parse(localStorage.getItem(STORE)||"null");
    if(loaded&&typeof loaded==="object"&&!Array.isArray(loaded)&&loaded.version===1){
      state={...state,...loaded,days:loaded.days&&typeof loaded.days==="object"&&!Array.isArray(loaded.days)?loaded.days:{},weeklyNotes:loaded.weeklyNotes&&typeof loaded.weeklyNotes==="object"&&!Array.isArray(loaded.weeklyNotes)?loaded.weeklyNotes:{}};
    }
  }catch(e){}
  if(!validDate(state.startDate))state.startDate=todayString();
  if(!modes[state.mode])state.mode="regular";
  if(!["dark","light"].includes(state.theme))state.theme="light";
  let toastTimer=null,savedWarning=false;
  function toast(message){
    const node=$("toast");if(!node)return;
    node.textContent=message;node.hidden=false;
    if(toastTimer)clearTimeout(toastTimer);
    toastTimer=setTimeout(()=>node.hidden=true,3500);
  }
  function save(){
    try{localStorage.setItem(STORE,JSON.stringify(state));}
    catch(e){if(!savedWarning){savedWarning=true;toast("浏览器禁止本地存储，请不要依赖当前打卡记录。");}}
  }
  function getDay(n){
    const d=state.days[String(n)];
    return d&&typeof d==="object"&&!Array.isArray(d)?d:{};
  }
  function updateDay(n,update){
    const old=getDay(n);
    state.days[String(n)]={...old,...update,updatedAt:new Date().toISOString()};
    save();
  }
  function startDateDay(n){
    const parts=state.startDate.split("-").map(Number);
    return new Date(parts[0],parts[1]-1,parts[2]+n-1);
  }
  function plannedToday(){
    const parts=state.startDate.split("-").map(Number),now=new Date();
    const x=Date.UTC(now.getFullYear(),now.getMonth(),now.getDate());
    const y=Date.UTC(parts[0],parts[1]-1,parts[2]);
    return Math.min(100,Math.max(1,Math.floor((x-y)/86400000)+1));
  }
  function currentDayLabel(n){
    const d=startDateDay(n);
    return d.getFullYear()+"."+pad(d.getMonth()+1)+"."+pad(d.getDate());
  }
  const queryDay=Number(new URLSearchParams(location.search).get("day"));
  let selectedDay=Number.isInteger(queryDay)&&queryDay>=1&&queryDay<=100?queryDay:plannedToday();
  const countChecked=day=>TASK_IDS.reduce((n,k)=>n+(getDay(day).tasks?.[k]===true?1:0),0);
  const isDone=day=>getDay(day).completed===true;
  const doneTotal=()=>DATA.days.reduce((n,d)=>n+(isDone(d.n)?1:0),0);
  const countActivities=()=>DATA.days.reduce((sum,d)=>sum+countChecked(d.n),0);
  const phaseIndex=day=>Math.min(4,Math.floor((day-1)/20));
  function activityPlan(n){
    const day=DATA.days[n-1];
    const core=day.steps.map((description,i)=>({
      id:"core"+(i+1),category:day.category,title:["明确任务","实践行动","沉淀结果"][i],description,
      check:["完成所述准备并留下一个可见记录","按要求做出实际尝试","将结果或修订写进笔记"][i],group:"core"
    }));
    const supplementary=SUPPORT.choose(day).map(x=>({
      id:x.id,category:x.category,title:x.title,description:x.action,check:x.check,group:"support"
    }));
    return [...core,...supplementary];
  }
  function categoryCounts(){
    const out=Object.fromEntries(Object.keys(DATA.categories).map(k=>[k,0]));
    DATA.days.forEach(day=>{
      const complete=getDay(day.n).tasks||{};
      if(["core1","core2","core3"].some(k=>complete[k]===true))out[day.category]++;
      SUPPORT.choose(day).forEach(x=>{if(complete[x.id]===true)out[x.category]++;});
    });
    return out;
  }
  function completionGate(n){
    const s=getDay(n),checked=s.tasks||{},core=["core1","core2","core3"];
    if(state.mode==="lite")return {ok:checked.core1===true,text:"轻量：完成第1步即可"};
    if(state.mode==="regular")return {ok:core.every(k=>checked[k]===true),text:"标准：完成核心3步"};
    return {ok:core.every(k=>checked[k]===true)&&(checked.support1===true||checked.support2===true)&&String(s.note||"").trim().length>=8,text:"深入：核心3步＋辅助1项＋至少8字笔记"};
  }
  function setTheme(){
    document.documentElement.dataset.theme=state.theme;
    const b=$("theme-toggle");if(b){b.setAttribute("aria-label",state.theme==="dark"?"切换浅色模式":"切换深色模式");b.title=state.theme==="dark"?"切换浅色模式":"切换深色模式";}
  }
  function renderDay(){
    const day=DATA.days[selectedDay-1],phase=DATA.phases[day.phase],d=getDay(selectedDay),tasks=activityPlan(selectedDay);
    const week=Math.ceil(selectedDay/7),gate=completionGate(selectedDay);
    $("start-date").value=state.startDate;
    $("prev-day").disabled=selectedDay===1;
    $("next-day").disabled=selectedDay===100;
    for(const button of $("mode-picker").querySelectorAll("button[data-mode]")){
      button.setAttribute("aria-pressed",String(button.dataset.mode===state.mode));
    }
    $("day-heading").innerHTML=`
      <div class="day-heading-text">
        <span class="day-status ${d.completed===true?"done":""}">${esc(phase.name)} · 第${week}周 ${d.completed===true?" · 已完成":""}</span>
        <h3>${esc(day.title)}</h3>
        <p>${esc(currentDayLabel(selectedDay))} · ${esc(DATA.categories[day.category])} · ${esc(modes[state.mode].time)}</p>
      </div><strong class="day-no">DAY ${String(selectedDay).padStart(3,"0")}</strong>`;
    const coreHtml=tasks.slice(0,3).map((t,i)=>`
      <button type="button" class="task core-task" data-task="${esc(t.id)}" aria-pressed="${d.tasks?.[t.id]===true}" aria-label="${esc(t.title)}：${esc(t.description)}，${d.tasks?.[t.id]===true?"已完成":"未完成"}">
        <span class="task-check" aria-hidden="true">✓</span>
        <span class="task-content"><span class="task-top"><span class="task-name"><b class="task-step-no">STEP ${pad(i+1)}</b> ${esc(t.title)}</span><span class="task-length">${i===0?"准备":i===1?"实践":"记录"}</span></span><span class="task-detail">${esc(t.description)}</span><span class="task-acceptance">验收：${esc(t.check)}</span></span>
      </button>`).join("");
    const supportHtml=tasks.slice(3).map((t,i)=>`
      <button type="button" class="task support-task" data-task="${esc(t.id)}" aria-pressed="${d.tasks?.[t.id]===true}" aria-label="${esc(t.title)}：${esc(t.description)}，${d.tasks?.[t.id]===true?"已完成":"未完成"}">
        <span class="task-check" aria-hidden="true">✓</span>
        <span class="task-content"><span class="task-top"><span class="task-name">${esc(t.title)}</span><span class="task-length">${esc(DATA.categories[t.category])}</span></span><span class="task-detail">${esc(t.description)}</span><span class="task-acceptance">完成证据：${esc(t.check)}</span></span>
      </button>`).join("");
    const linked=day.link?DATA.days[day.link-1]:null;
    const linkedText=linked?`<a href="?day=${day.link}" class="path-link" data-open-day="${day.link}">↖ 相关前置 · Day ${pad(day.link)}「${esc(linked.title)}」</a>`:`<span class="path-link path-label">起点日 · 先观察，不急着改变</span>`;
    const next=selectedDay<100?DATA.days[selectedDay]:null;
    const nextText=next?`<a href="?day=${next.n}" class="path-link" data-open-day="${next.n}">下一个主题 · ${esc(next.title)} ↗</a>`:`<span class="path-link path-label">全部100天课程的最后一课</span>`;
    const checked=countChecked(selectedDay),completed=d.completed===true;
    const legacy=completed&&checked===0&&Object.keys(d.tasks||{}).some(k=>LEGACY_IDS.includes(k))?`<p class="legacy-note">此日保留了旧版完成记录；新版步骤尚未单独核验。</p>`:"";
    $("day-content").innerHTML=`
      <div class="weekly-brief"><div><span class="brief-label">THIS WEEK / WEEK ${pad(week)}</span><strong>${esc(SUPPORT.weeklyObjectives[week-1])}</strong></div><span class="brief-phase">本阶段：${esc(DATA.phaseOutcomes[day.phase])}</span></div>
      <div class="day-body">
        <div class="daily-left">
          <p class="card-microheading">01 / MAIN PRACTICE · ${esc(DATA.categories[day.category])}</p>
          <h4 class="block-title">今天只聚焦一件事。</h4>
          <p class="block-desc">3个具体步骤，按顺序完成。每个步骤有独立打卡，避免把“看过课程”当作“做过练习”。</p>
          <div class="outcome-card"><span class="mini-label">今天要留下什么</span><p>${esc(day.proof)}</p></div>
          <div class="task-list main-task-list">${coreHtml}</div>
          <div class="path-box"><div class="path-title">学习衔接 · 在旧成果上继续</div><div class="path-links">${linkedText}${nextText}</div><p>前置课程可随时查看，没有完成也可以继续当前课程；关联是学习建议，不是强制解锁。</p></div>
        </div>
        <div class="daily-right">
          <p class="card-microheading">02 / SUPPORTING PRACTICE</p><h4 class="block-title">穿插两项生活巩固。</h4>
          <p class="block-desc">结合本周节律安排，自动避开当天主线领域。与昨天不同，隔周可有目的地复练。</p>
          <div class="task-list support-task-list">${supportHtml}</div>
          <div class="training-rules"><span class="mini-label">本日确认规则</span><strong>${esc(gate.text)}</strong><p>${esc(modes[state.mode].hint)} 运动、饮食和冥想都应根据自己的健康状况与负荷调整。</p></div>
          <div class="journal-card">
            <span class="card-microheading">03 / WRITTEN REFLECTION</span><h4>给今天留一条证据。</h4>
            <p class="journal-question">${esc(day.question)}</p>
            <label class="sr-only" for="day-note">今日反思与成果笔记</label>
            <textarea id="day-note" maxlength="5000" placeholder="例如：今天实际做了什么？留下了什么成果？下一次会怎样调整？">${esc(d.note||"")}</textarea>
            <p class="journal-tip">笔记自动保存于当前浏览器；不要记录身份证、病历等敏感个人信息。</p>
            <div class="energy-row"><label>今天的精力状态（可选）</label><div class="energy-options" role="group" aria-label="精力状态，1分较低，5分充沛">${[1,2,3,4,5].map(i=>`<button type="button" data-energy="${i}" aria-label="精力 ${i} 分" aria-pressed="${d.energy===i}">${i}</button>`).join("")}</div></div>
          </div>
        </div>
      </div>
      <div class="day-checkout"><div class="checkout-progress"><div class="completion-bar" role="progressbar" aria-label="当天具体任务完成进度" aria-valuemin="0" aria-valuemax="5" aria-valuenow="${checked}"><div class="completion-fill" style="width:${checked/5*100}%"></div></div><div class="completion-meta"><span>已完成 ${checked}/5 个具体任务</span><span>${gate.ok?"已达到当前模式的验收条件":"尚未达到当前模式的验收条件"}</span></div>${legacy}</div><button type="button" class="done-button ${completed?"is-done":""}" id="finish-day">${completed?"✓ 已确认 · 点击撤销":"✓ 按本模式确认完成"}</button></div>`;
  }
  function renderStats(){
    const completed=doneTotal(),activities=countActivities(),ph=phaseIndex(plannedToday());
    const phaseDone=DATA.days.slice(ph*20,ph*20+20).filter(x=>isDone(x.n)).length;
    $("stats").innerHTML=[
      [pad(completed),"亲自确认完成的天数"],
      [pad(plannedToday()),"距离起点的计划日"],
      [String(activities),"已经完成的小行动"],
      [pad(phaseDone)+"/20","本阶段已完成天数"]
    ].map(([v,label])=>`<div class="stat"><b>${esc(v)}</b><span>${esc(label)}</span></div>`).join("");
    $("hero-progress").innerHTML=`<strong>${completed} / 100</strong><small>完成的日子 · ${Math.round(completed)}% 的旅程</small>`;
  }
  function renderPhases(){
    $("phase-list").innerHTML=DATA.phases.map((p,i)=>{
      const completed=DATA.days.slice(i*20,i*20+20).filter(d=>isDone(d.n)).length;
      return `<button type="button" class="phase-card" data-open-day="${i*20+1}" aria-label="${esc(p.name)}，第${i*20+1}至${(i+1)*20}天，已完成${completed}天">
        <span class="phase-number">${p.code}</span><span class="phase-copy"><strong>${esc(p.name)}</strong><small>DAY ${esc(p.days)} · ${completed}/20</small><p>${esc(p.caption)}</p><span class="phase-progress"><span style="width:${completed*5}%"></span></span></span></button>`;
    }).join("");
  }
  function renderMap(){
    const current=plannedToday();
    $("day-map").innerHTML=DATA.days.map(d=>{
      const s=getDay(d.n),complete=s.completed===true,partial=countChecked(d.n)>0||!!s.note||Number.isInteger(s.energy);
      const className=complete?"done":partial?"partial":"";
      return `<button type="button" class="map-day ${className} ${d.n===current?"current":""}" data-open-day="${d.n}" style="--phase-color:${DATA.phases[d.phase].color}" title="第${d.n}天 · ${esc(d.title)}" aria-label="第 ${d.n} 天：${esc(d.title)}${complete?"，已完成":partial?"，进行中":""}" aria-current="${d.n===selectedDay?"true":"false"}"><span>${pad(d.n)}</span><small>${complete?"完成":partial?"记录":"DAY"}</small></button>`;
    }).join("");
  }
  function renderDimensions(){
    $("dimension-grid").innerHTML=DATA.dimensions.map((x,i)=>`<article class="dimension-card"><span class="dimension-icon" aria-hidden="true">${esc(x.icon)}</span><h3>${pad(i+1)}. ${esc(x.name)}</h3><p>${esc(x.desc)}</p></article>`).join("");
  }
  function renderCharts(){
    let weekHtml="";
    for(let w=0;w<15;w++){
      const low=w*7+1,high=Math.min(100,(w+1)*7),total=high-low+1;
      let count=0;for(let d=low;d<=high;d++)if(isDone(d))count++;
      weekHtml+=`<div class="week" title="第${w+1}周，${count}/${total}天" role="img" aria-label="第${w+1}周，完成${count}天，共${total}天"><div class="week-track"><div class="week-fill" style="height:${Math.round(count/total*100)}%"></div></div><small>${w+1}</small></div>`;
    }
    $("weekly-chart").innerHTML=weekHtml;
    const counts=categoryCounts(),max=Math.max(1,...Object.values(counts));
    $("habit-chart").innerHTML=Object.entries(DATA.categories).map(([k,name])=>{
      const n=counts[k];return `<div class="habit-row"><span>${esc(name)}</span><div class="habit-track" role="progressbar" aria-label="${esc(name)}训练次数" aria-valuemin="0" aria-valuemax="${max}" aria-valuenow="${n}"><div class="habit-fill" style="width:${Math.round(n/max*100)}%"></div></div><b>${n}</b></div>`;
    }).join("");
    const week=Math.ceil(selectedDay/7);
    $("review-panel").innerHTML=`<div><span class="card-microheading">WEEKLY REVIEW / ${pad(week)}</span><h3>本周真正积累了什么？</h3><p>${esc(SUPPORT.weeklyObjectives[week-1])} · Day ${pad((week-1)*7+1)}—${pad(Math.min(100,week*7))}。</p><p>回看可见产出、没有做到的原因，以及下周准备调整的最小一件事。</p></div><div><label class="sr-only" for="weekly-note">第${week}周复盘笔记</label><textarea id="weekly-note" maxlength="5000" data-week="${week}" placeholder="本周保留什么证据？持续什么？调整什么？">${esc(state.weeklyNotes[String(week)]||"")}</textarea><p class="journal-tip">自动保存于当前浏览器，不公开上传。</p></div>`;
  }
  function render(){setTheme();renderDay();renderStats();renderPhases();renderMap();renderCharts();}
  function selectDay(n,scroll=true){
    const x=Number(n);
    if(!Number.isInteger(x)||x<1||x>100)return;
    selectedDay=x;
    history.replaceState(null,"",location.pathname+"?day="+x+location.hash);
    renderDay();renderMap();renderCharts();
    if(scroll)$("today").scrollIntoView({behavior:window.matchMedia("(prefers-reduced-motion: reduce)").matches?"auto":"smooth",block:"start"});
  }
  function download(filename,content,type){
    const file=new Blob([content],{type}),url=URL.createObjectURL(file),a=document.createElement("a");
    a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();
    setTimeout(()=>URL.revokeObjectURL(url),10000);
  }
  function exportData(){
    const out={...state,exportedAt:new Date().toISOString(),app:"100-days-of-becoming"};
    download("日有寸进-100天记录-"+todayString()+".json",JSON.stringify(out,null,2),"application/json;charset=utf-8");
    toast("完整记录已导出，请妥善保存。");
  }
  function exportReport(){
    const counts=categoryCounts();
    const lines=[
      "# 日有寸进｜100天个人成长记录","",
      "导出时间："+new Date().toLocaleString("zh-CN"),"起点日期："+state.startDate,
      "已确认完成："+doneTotal()+" / 100 天","具体任务勾选："+countActivities()+" 项","",
      "## 八个能力与生活领域",
      ...Object.entries(DATA.categories).map(([k,name])=>"- "+name+"："+counts[k]+" 项"),"","## 阶段记录",
      ...DATA.phases.flatMap((p,i)=>["### "+p.name,"阶段目标："+DATA.phaseOutcomes[i],DATA.days.slice(i*20,i*20+20).filter(x=>isDone(x.n)).length+" / 20 天",""]),
      "## 每日课程与成果笔记"
    ];
    DATA.days.forEach(day=>{
      const d=getDay(day.n),count=countChecked(day.n);
      if((d.note||"").trim()||d.completed===true||count>0){
        lines.push("### Day "+pad(day.n)+" · "+day.title+(d.completed?"（已确认完成）":""));
        lines.push("预期成果："+day.proof);
        lines.push("当前已勾选："+count+" / 5 项");
        if(Number.isInteger(d.energy))lines.push("主观精力："+d.energy+" / 5");
        if(d.note)lines.push("反思："+d.note.trim());
        lines.push("");
      }
    });
    lines.push("## 每周复盘");
    Object.entries(state.weeklyNotes).sort((a,b)=>Number(a[0])-Number(b[0])).forEach(([k,v])=>{if(v&&v.trim())lines.push("### 第 "+k+" 周",v.trim(),"")});
    lines.push("","---","个人练习记录，不代表医疗评估或客观健康结论。");
    download("日有寸进-成长档案-"+todayString()+".md",lines.join("\\n"),"text/markdown;charset=utf-8");
    toast("成长档案已导出。");
  }
  function validateImport(obj){
    if(!obj||typeof obj!=="object"||Array.isArray(obj)||obj.version!==1||!validDate(obj.startDate))throw Error("备份文件格式不正确");
    const clean=fresh();
    clean.startDate=obj.startDate;
    clean.mode=modes[obj.mode]?obj.mode:"regular";
    clean.theme=["light","dark"].includes(obj.theme)?obj.theme:"light";
    if(obj.days&&typeof obj.days==="object"&&!Array.isArray(obj.days)){
      for(const [k,v] of Object.entries(obj.days)){
        const n=Number(k);
        if(!Number.isInteger(n)||n<1||n>100||!v||typeof v!=="object"||Array.isArray(v))continue;
        const tasks={};
        for(const id of [...TASK_IDS,...LEGACY_IDS]){if(v.tasks&&v.tasks[id]===true)tasks[id]=true;}
        clean.days[String(n)]={tasks,completed:v.completed===true,note:typeof v.note==="string"?v.note.slice(0,5000):"",energy:Number.isInteger(v.energy)&&v.energy>=1&&v.energy<=5?v.energy:null};
      }
    }
    if(obj.weeklyNotes&&typeof obj.weeklyNotes==="object"&&!Array.isArray(obj.weeklyNotes)){
      for(const [k,v] of Object.entries(obj.weeklyNotes)){
        const w=Number(k);
        if(Number.isInteger(w)&&w>=1&&w<=15&&typeof v==="string")clean.weeklyNotes[String(w)]=v.slice(0,5000);
      }
    }
    return clean;
  }
  async function importData(file){
    if(!file)return;
    if(file.size>1024*1024){toast("文件超过1MB，请选择正确的JSON记录。");return;}
    try{
      const next=validateImport(JSON.parse(await file.text()));
      if(!confirm("导入将替换本浏览器中的现有100天记录，建议先导出备份。确定继续吗？"))return;
      state=next;selectedDay=plannedToday();save();render();
      toast("记录已导入，当前浏览器的进度已恢复。");
    }catch(e){toast("无法导入："+(e instanceof Error?e.message:"文件内容有误"));}
  }
  $("start-date").addEventListener("change",e=>{
    const value=e.target.value;
    if(!validDate(value)){toast("请选择有效日期。");e.target.value=state.startDate;return;}
    state.startDate=value;save();selectDay(plannedToday(),false);renderStats();
    toast("新的起点日期已保存，原有Day编号记录保持不变。");
  });
  $("theme-toggle").addEventListener("click",()=>{state.theme=state.theme==="light"?"dark":"light";save();setTheme();});
  $("prev-day").addEventListener("click",()=>selectDay(selectedDay-1));
  $("next-day").addEventListener("click",()=>selectDay(selectedDay+1));
  $("go-today").addEventListener("click",()=>selectDay(plannedToday()));
  $("mode-picker").addEventListener("click",e=>{
    const b=e.target.closest("button[data-mode]");
    if(!b||!modes[b.dataset.mode])return;
    state.mode=b.dataset.mode;save();renderDay();
    toast("已切换到"+modes[state.mode].name+"模式。");
  });
  $("day-content").addEventListener("click",e=>{
    const task=e.target.closest("button[data-task]");
    if(task){
      const key=task.dataset.task,d=getDay(selectedDay),tasks={...(d.tasks||{})};
      tasks[key]=!tasks[key];updateDay(selectedDay,{tasks});
      renderDay();renderStats();renderMap();renderCharts();
      return;
    }
    const energy=e.target.closest("button[data-energy]");
    if(energy){
      const value=Number(energy.dataset.energy),d=getDay(selectedDay);
      updateDay(selectedDay,{energy:d.energy===value?null:value});
      renderDay();renderMap();return;
    }
    if(e.target.closest("#finish-day")){
      const d=getDay(selectedDay),isPrevious=d.completed===true;
      if(!isPrevious&&!completionGate(selectedDay).ok){
        toast("当前模式尚未达标。可以完成相应核心步骤，或选择更适合今天的轻量模式。");return;
      }
      updateDay(selectedDay,{completed:!isPrevious,completedMode:isPrevious?null:state.mode});
      render();toast(isPrevious?"已撤销当日完成确认。":"本日成果已记录。");
    }
  });
  $("day-content").addEventListener("input",e=>{
    if(e.target.id==="day-note"){updateDay(selectedDay,{note:e.target.value});}
  });
  $("day-content").addEventListener("click",e=>{
    const a=e.target.closest("a[data-open-day]");
    if(a){e.preventDefault();selectDay(Number(a.dataset.openDay));}
  });
  $("journey").addEventListener("click",e=>{
    const b=e.target.closest("button[data-open-day]");
    if(b)selectDay(Number(b.dataset.openDay));
  });
  $("history").addEventListener("input",e=>{
    if(e.target.id==="weekly-note"){
      const week=String(e.target.dataset.week);
      state.weeklyNotes[week]=e.target.value;
      save();
    }
  });
  $("export-data").addEventListener("click",exportData);
  $("export-report").addEventListener("click",exportReport);
  $("import-trigger").addEventListener("click",()=>$("import-file").click());
  $("import-file").addEventListener("change",async e=>{await importData(e.target.files?.[0]);e.target.value="";});
  $("print-day").addEventListener("click",()=>window.print());
  window.addEventListener("scroll",()=>{
    const max=document.documentElement.scrollHeight-window.innerHeight;
    const fraction=max>0?window.scrollY/max:0;
    $("site-progress").style.width=Math.round(Math.min(1,Math.max(0,fraction))*100)+"%";
  },{passive:true});
  window.addEventListener("popstate",()=>{
    const d=Number(new URLSearchParams(location.search).get("day"));
    if(Number.isInteger(d)&&d>=1&&d<=100){selectedDay=d;renderDay();renderMap();renderCharts();}
  });
  renderDimensions();
  render();
})();
